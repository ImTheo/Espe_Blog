import React, {useState} from 'react';
import ReactDOM from 'react-dom';
import './index.css';

import imagenBgr from './body_bg.jpg';
import imagenLgd from './Logo_dark.png';
import imagenUser from './pngwing.com.png';
import imagenLgl from './sun.png';

function HeaderUser(){
    return (<header>
        <nav>
            <a className='nav__a' href='/'>Inicio</a>
            <a className='nav__a' href='/'>Noticias</a>
            <a className='nav__logo' href='/'>
                <img className='nav__logo__img' src={imagenLgd} alt='/'/>
            </a>
            <a className='nav__a' href='/'>Comunidad</a>
            <a className='nav__a' href='/'>Blog</a>
        </nav>
        <img className='nav__img' src={imagenLgl} alt='/'/>
    </header>);
}

function Publication() {
    return (<div className='publication'>
        <img className='publication-img' src={' '} alt=''/>
        <h3 className='publication-h3'>Titulo</h3>
        <p className='publication-description'>Description</p>
    </div>);
}

function BoardPublication() {
    return(
        <div className='boardPublication'>
            <Publication />
            <Publication />
            <Publication />
            <Publication />
        </div>
    );
}

function EditUser(props){
    // var show = ()=>{}
    return(
        <div className='editContainer' style={{display: props.value}}>
            <label>Nombre de ususario</label>
            <input type={'text'}></input>
            <img alt=''/>
            <label>Foto de perfil</label>
            <button>Guardar</button>
        </div>
    );
}

function User() {
    var show='none';
    const[count, setCount]=useState(0);
    return (
        <div>
            <HeaderUser />
            <img id='img-bkg' src={imagenBgr} alt=''/>
            <div id='user-container'>
                <div id='user-data'>
                    <img id='user-img' src={imagenUser} alt=''/>
                    <label className='user-lbl'>Nombre de usuario</label>
                    <label className='user-lbl'>usuario@espe.edu.ec</label>
                    <button onClick={()=>setCount(count+1)}>Editar Perfil</button>
                    <EditUser value={show}/>
                </div>
                <div id='user-activity'>
                    <label className='user-lbl'>Comentarios: #</label>
                    <label className='user-lbl'>Preguntas: #</label>
                    <h3 className='user-h3'>Publicaciones activas</h3>
                    <BoardPublication />
                    <button className='user-btn'>ver más</button>
                </div>
            </div>
        </div>    
    );
}

ReactDOM.render(<User />, document.getElementById("root"));
